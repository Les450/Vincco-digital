/* ══════════════════════════════════════════════════════════════
   Promociones vistas desde el lado del cliente.

   Antes el Home leía las promociones guardadas y las achataba a
   cuatro campos para dibujar la tarjeta: el título entraba como
   categoría, la descripción como nombre, y el descuento real, las
   unidades, la vigencia y los términos se perdían en el camino.
   Mientras la tarjeta no se podía tocar eso no molestaba.

   Ahora sí: al abrir el detalle hace falta todo, y sobre todo hace
   falta saber DE QUÉ NEGOCIO es la promoción. Sin eso no hay a
   quién escribirle por WhatsApp ni a quién avisarle de la consulta.

   Este es el único lugar donde se traduce lo que el negocio publicó
   a lo que el cliente ve. Si mañana las publicaciones salen de
   Postgres en vez de localStorage, se cambia acá y ninguna pantalla
   se entera.
   ══════════════════════════════════════════════════════════════ */

import { promociones as promocionesEjemplo } from '../data/data_falso'

export const CLAVE_PROMOCIONES = 'pn_promociones'

// El naranja de marca es el color por defecto de una promoción.
const COLOR_PROMO = '#c05900'

// Cada sucursal publica aparte ("pn_promociones:n1"), igual que el
// inventario. Sin sucursal se usa la clave clásica.
export function clavePromociones(sucursalId) {
  return sucursalId ? `${CLAVE_PROMOCIONES}:${sucursalId}` : CLAVE_PROMOCIONES
}

export function leerPublicaciones(clave) {
  try {
    const guardado = JSON.parse(localStorage.getItem(clave) || 'null')
    if (Array.isArray(guardado)) return guardado
  } catch {
    // localStorage bloqueado o JSON roto: se sigue con la lista vacía
  }
  return []
}

/* Datos del negocio que acompañan a una promoción.

   Las publicaciones creadas antes de este cambio no guardaron nada
   del negocio, así que hay que completarlas con el perfil que está
   activo. En la demo eso es correcto porque todo vive en el mismo
   navegador; con backend, `pub.negocio` siempre va a venir lleno y
   el respaldo deja de usarse solo.                                */
export function negocioDePromocion(pub, respaldo = null) {
  const guardado = pub?.negocio
  if (guardado?.nombre) return guardado
  if (!respaldo) return null

  return {
    id: respaldo.id || null,
    nombre: respaldo.nombre || '',
    categoria: respaldo.categoria || '',
    telefono: respaldo.telefono || '',
    whatsapp: respaldo.whatsapp || respaldo.telefono || '',
    direccion: respaldo.direccion || '',
    descripcion: respaldo.descripcion || '',
    foto: respaldo.foto || null,
    verificado: Boolean(respaldo.verificado),
  }
}

/* Una publicación del panel → la promoción que ve el cliente.
   Acá no se pierde ningún campo: lo que el negocio escribió es lo
   que el cliente puede leer.                                      */
export function normalizarPromocion(pub, respaldoNegocio = null) {
  const descuento = pub.descuento === '' || pub.descuento == null ? null : Number(pub.descuento)
  const unidades = pub.unidades === '' || pub.unidades == null ? null : Number(pub.unidades)
  const esLimitada = pub.tipo === 'limitada'

  return {
    id: pub.id,
    origen: 'publicacion',
    titulo: pub.titulo || '',
    descripcion: pub.descripcion || '',
    imagen: pub.imagen || null,
    descuento,
    unidades,
    puntos: pub.puntos || null,
    validoHasta: pub.validoHasta || null,
    terminos: pub.terminos || '',
    categoria: pub.categoriaPromocion || 'Otros',
    esLimitada,
    fecha: pub.fecha || null,
    badge: descuento ? `${descuento}% OFF` : esLimitada ? 'Limitada' : 'Promoción',
    color: COLOR_PROMO,
    negocio: negocioDePromocion(pub, respaldoNegocio),
  }
}

/* Las promociones de ejemplo de data_falso tienen otra forma: ahí
   "nombre" es el nombre del comercio, no el de la oferta. Se
   traducen a la misma figura para que el detalle no tenga que
   preguntar de dónde vino cada una.                               */
export function normalizarPromocionEjemplo(p) {
  return {
    id: p.id,
    origen: 'ejemplo',
    // En las de ejemplo el gancho ES el beneficio ("2x puntos hoy"),
    // así que ese texto va de título y el chip de puntos se queda
    // vacío a propósito: repetirlo dos veces no suma nada.
    titulo: p.puntos,
    descripcion: `Promoción vigente en ${p.nombre}. Consultá al negocio por las condiciones.`,
    imagen: null,
    descuento: null,
    unidades: null,
    puntos: null,
    validoHasta: null,
    terminos: '',
    categoria: p.categoria,
    esLimitada: p.badge === 'Limitado',
    fecha: null,
    badge: p.badge,
    color: p.color || COLOR_PROMO,
    negocio: {
      id: null,
      nombre: p.nombre,
      categoria: p.categoria,
      telefono: '',
      whatsapp: '',
      direccion: 'Nueva Guinea, RACCS',
      descripcion: '',
      foto: null,
      verificado: false,
    },
  }
}

/* Todas las claves de publicaciones que hay en el navegador.

   Hace falta porque cada sucursal guarda aparte y el cliente no
   tiene una "sucursal activa": tiene que ver lo de todos.

   Esto además arregla algo que estaba roto de antes y no se notaba:
   el Home leía siempre "pn_promociones" a secas, pero el panel
   guarda en "pn_promociones:n1" apenas hay una sucursal activa
   (y hay una por defecto). O sea que el cliente nunca veía lo que
   el negocio publicaba — siempre caía en las promociones de
   ejemplo y parecía que todo funcionaba.                          */
function clavesDePromociones() {
  const claves = []
  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const clave = localStorage.key(i)
      if (clave && clave.startsWith(CLAVE_PROMOCIONES)) claves.push(clave)
    }
  } catch {
    // Sin localStorage no hay publicaciones que leer
  }
  return claves
}

/* Lista lista para el Home.

   - `clave` puesta  → solo esa (el socio viendo su propio Home ve
                       lo de la sucursal en la que está parado).
   - `clave` en null → todas (el cliente ve lo de todos los negocios).

   `limitadas` separa las promociones limitadas de las normales,
   que en el Home viven en dos secciones distintas.                */
export function promocionesVisibles({ clave = null, respaldo = null, limitadas = false } = {}) {
  const claves = clave ? [clave] : clavesDePromociones()

  const publicadas = claves
    .flatMap((k) => leerPublicaciones(k))
    .filter((p) => (limitadas ? p.tipo === 'limitada' : p.tipo !== 'limitada'))
    .map((p) => normalizarPromocion(p, respaldo))
    // Las más nuevas primero: el id es el Date.now() de cuando se creó
    .sort((a, b) => Number(b.id) - Number(a.id))

  if (publicadas.length > 0) return publicadas
  if (limitadas) return []
  return promocionesEjemplo.map(normalizarPromocionEjemplo)
}

/* Busca una promoción por id sin saber de qué sucursal es.

   La pantalla /promocion/:id se puede abrir desde un link, sin
   pasar por el Home, así que no recibe el objeto ya armado: tiene
   que ir a buscarlo. Recorre todas las claves de publicaciones que
   haya en el navegador, incluidas las de cada sucursal.           */
export function buscarPromocion(id, respaldoNegocio = null) {
  const buscado = String(id)

  try {
    for (let i = 0; i < localStorage.length; i += 1) {
      const clave = localStorage.key(i)
      if (!clave || !clave.startsWith(CLAVE_PROMOCIONES)) continue

      const encontrada = leerPublicaciones(clave).find((p) => String(p.id) === buscado)
      if (encontrada) return normalizarPromocion(encontrada, respaldoNegocio)
    }
  } catch {
    // Sin localStorage se cae a las de ejemplo
  }

  const ejemplo = promocionesEjemplo.find((p) => String(p.id) === buscado)
  return ejemplo ? normalizarPromocionEjemplo(ejemplo) : null
}

/* Los puntos como los tiene que leer una persona.

   El panel guarda un número suelto ("50") porque el campo pide un
   número, pero "50" solo, en una tarjeta, no dice nada. Las
   promociones de ejemplo en cambio ya traen la frase entera
   ("2x puntos hoy") y hay que dejarla tal cual.                   */
export function textoPuntos(puntos) {
  if (puntos == null || puntos === '') return null

  const numero = Number(puntos)
  if (Number.isFinite(numero) && String(puntos).trim() !== '') {
    return `${numero} ${numero === 1 ? 'punto' : 'puntos'}`
  }

  return String(puntos)
}

/* Texto de vigencia en palabras. Devuelve null si no hay fecha,
   para que la pantalla directamente no muestre la línea.          */
export function textoVigencia(validoHasta) {
  if (!validoHasta) return null

  const hasta = new Date(`${validoHasta}T23:59:59`)
  if (Number.isNaN(hasta.getTime())) return null

  // floor y no ceil: la fecha se cierra a las 23:59 del último día,
  // así que redondear hacia arriba regalaba un día que no existe.
  const dias = Math.floor((hasta.getTime() - Date.now()) / 86400000)
  if (dias < 0) return 'Promoción vencida'
  if (dias === 0) return 'Último día'
  if (dias === 1) return 'Queda 1 día'
  if (dias <= 7) return `Quedan ${dias} días`

  return `Válida hasta el ${hasta.getDate()}/${hasta.getMonth() + 1}`
}

/* Link de WhatsApp con el mensaje ya escrito. Mismo patrón que usan
   CotizacionesPanel y CotizacionesEnviadas: se limpia todo lo que
   no sea número porque los teléfonos se guardan con espacios y +.  */
export function linkWhatsApp(numero, mensaje) {
  const limpio = String(numero || '').replace(/\D/g, '')
  if (!limpio) return null
  return `https://wa.me/${limpio}?text=${encodeURIComponent(mensaje)}`
}

export function mensajeWhatsApp(promo, nombreCliente) {
  const saludo = nombreCliente ? `Hola, soy ${nombreCliente}.` : 'Hola.'
  return `${saludo} Vi en Vincco la promoción "${promo.titulo}"${
    promo.negocio?.nombre ? ` de ${promo.negocio.nombre}` : ''
  } y quería consultar por ella.`
}
